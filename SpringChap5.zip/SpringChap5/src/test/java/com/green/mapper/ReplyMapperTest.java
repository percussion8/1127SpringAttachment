package com.green.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.green.domain.Criteria;
import com.green.domain.ReplyVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		"file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTest {
	@Setter(onMethod_=@Autowired)
	private ReplyMapper mapper;
	
	private Long[] bnoArr = {60L, 61L, 62L};
	
	//@Test
	public void insertTest() {
		ReplyVO reply = new ReplyVO();
		reply.setBno(60L);
		reply.setReply("f*king tired");
		reply.setReplyer("Me");
		
		mapper.insert(reply);
	}
	
	//@Test
	public void readTest() {
		log.info(mapper.read(1L));
	}
	
	//@Test
	public void deleteTest() {
		log.info(mapper.delete(1L) + "개의 댓글이 삭제되었습니다.");
	}
	
	//@Test
	public void updateTest() {
		ReplyVO reply = new ReplyVO();
		reply.setRno(2L);
		reply.setReply("almost there. I will soon call it a day.");
		
		log.info(mapper.update(reply) + "개의 댓글이 수정되었습니다.");
	}
	
	//@Test
	public void pagingTest() {
		Criteria crit = new Criteria();
		List<ReplyVO> replies = mapper.getListWithPaging(crit, bnoArr[0]);
		
		replies.forEach(reply -> log.info(reply));
		
		
	}
	
	//@Test
	public void testList2() {
		Criteria crit = new Criteria(2, 10);
		List<ReplyVO> replies = mapper.getListWithPaging(crit, 15880L);
		replies.forEach(i -> log.info(i));
	}
	
	@Test
	public void getCountTest() {
		log.info("댓글 개수는? :" + mapper.getCountbyBno(15880L));
	}

}
